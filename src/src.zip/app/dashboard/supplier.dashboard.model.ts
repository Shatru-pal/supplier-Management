export class SupplierModel{
    id : number =0;
    firstName :string ='';
    lastName :string ='';
    email :string='';
    mobile :string='';
    product:string='';
}